# DIY Drone RC

Bộ điều khiển drone tự chế: **tay cầm ESP32** + **mạch thu ESP32-S3** + **flight controller STM32F407**, liên lạc không dây bằng ESP-NOW (WiFi 2.4 GHz), không cần module ELRS/FlySky.

> DIY drone remote control: ESP32 transmitter, ESP32-S3 receiver that emulates an ELRS (CRSF) receiver, and an STM32F407 flight controller with self-leveling and barometric altitude hold.

---

## Tổng quan

```
 [ESP32 TX]  ──ESP-NOW (100 gói/giây)──►  [ESP32-S3 RX]  ──CRSF 420000 baud──►  [STM32F407 FC]
  tay cầm                                  giả lập máy thu ELRS                    tự cân bằng + giữ độ cao
  2 joystick + nút bấm   ◄──telemetry──     đọc telemetry FC gửi ra
```

Mạch RX nói chuyện với FC đúng như một máy thu ELRS thật, nên phần nhận của FC không phải sửa.

### Tính năng

- **TX (ESP32):** đọc 2 joystick (4 trục), nút ARM, nút đổi chế độ bay, 4 nút trim; gửi 50 đến 250 gói/giây (mặc định 100); hiệu chuẩn cần và lưu vào flash; nhận telemetry hiển thị trên Serial.
- **RX (ESP32-S3):** nhận ESP-NOW, đổi sang khung CRSF 8 kênh gửi FC; đọc telemetry từ FC (góc, độ cao, tốc độ lên xuống, chế độ bay) gửi về tay; đo chất lượng liên kết (LQ); 2 LED ngoài báo có sóng / mất sóng.
- **FC (STM32F407):** tự cân bằng (PID rate + PID góc), giữ độ cao bằng baro (Kalman 2D + EKF), 4 ESC PWM 250 Hz, failsafe cắt motor khi mất sóng quá 500 ms, in trạng thái qua USB COM.
- **An toàn:** chỉ ARM khi ga ở mức thấp; giữ nút ARM 1 giây để ARM, giữ 0,4 giây để DISARM khẩn cấp; mỗi lần ARM tự ép về chế độ STAB; chưa hiệu chuẩn cần thì TX từ chối ARM.

> Bản này **chỉ có tự cân bằng và giữ độ cao (baro)**. Không có GPS, không có la bàn.

---

## Cấu trúc thư mục

```
DIY_Drone_RC/
├── TX_ESP32/        TX_ESP32.ino  RcProtocol.h  TxLogic.h     -> nạp cho ESP32 (tay cầm)
├── RX_ESP32S3/      RX_ESP32S3.ino  RcProtocol.h  Crsf.h      -> nạp cho ESP32-S3 (trên drone)
├── FC_F405/         FC_F405.ino + các tab (IMU, Baro, PID,    -> nạp cho STM32F407
│                    Motors, EKF, CRSF, Debug...) + Config.h
├── README.txt
└── PATCH_NOTES_STM32duino_3.1.0.txt
```

Mỗi thư mục là một sketch Arduino riêng. `Config.h` của FC chứa toàn bộ thông số chỉnh được (chân, PID, ngưỡng ARM, độ nhạy cần...).

> `RcProtocol.h` ở TX và RX **phải giống hệt nhau** (kênh WiFi, `RC_LINK_KEY`, `RC_USE_LR_MODE`, cấu trúc gói). Sửa chỗ nào thì chép sang chỗ kia.

---

## Phần cứng

| Thành phần | Linh kiện |
|---|---|
| Tay cầm | ESP32 (ESP32 Dev Module), 2 joystick analog, 6 nút bấm, 1 LED |
| Mạch thu | ESP32-S3 N16R8, 2 LED + điện trở 220 đến 330 Ω |
| Flight controller | STM32F407, IMU ICM-20602 (SPI), baro BMP388 (SPI) |
| Động cơ | 4 ESC (PWM 250 Hz) |

## Sơ đồ chân

**RX (ESP32-S3) nối FC (STM32F407)**, UART đấu chéo, bắt buộc chung GND:

| ESP32-S3 | STM32F407 | Nội dung |
|---|---|---|
| GPIO17 (TX) | PA1 (UART4 RX) | Lệnh điều khiển CRSF, 420000 baud |
| GPIO18 (RX) | PA0 (UART4 TX) | Telemetry từ FC |
| GND | GND | Chung mass |
| 5V | 5V (BEC) | Không lấy từ chân 3.3V của FC |
| GPIO4 | LED xanh | Có sóng (qua điện trở) |
| GPIO5 | LED đỏ | Mất sóng (qua điện trở) |

Không dùng GPIO 26 đến 37 trên ESP32-S3 N16R8 (flash/PSRAM octal).

**TX (ESP32)**, đổi ở đầu `TX_ESP32.ino`:

| Chức năng | GPIO |
|---|---|
| Roll / Pitch (cần phải) | 32 / 33 |
| Ga / Yaw (cần trái) | 35 / 34 |
| ARM / MODE | 25 / 26 |
| Trim roll trái / phải | 27 / 14 |
| Trim pitch lên / xuống | 13 / 4 |
| LED báo | 2 |

Joystick cấp 3V3 (không cấp 5V vào chân ADC). Nút bấm một đầu nối GND, đã bật pull-up trong chip. Chỉ dùng chân ADC1 vì ADC2 không đọc được khi bật WiFi.

**FC (STM32F407)**, xem `FC_F405/Config.h`:

| Chức năng | Chân |
|---|---|
| SPI1 (IMU + baro) | PA5 (SCK), PA6 (MISO), PA7 (MOSI) |
| CS ICM-20602 / BMP388 | PA4 / PA3 |
| ESC 1 đến 4 | PC6, PC7, PC8, PC9 |
| LED có sóng / mất sóng | PB3 / PB4 |

---

## Cài đặt

| Board | Cài đặt Arduino IDE |
|---|---|
| TX | Board **ESP32 Dev Module**, core ESP32 **3.0.7** (xem lưu ý bên dưới), Serial 115200 |
| RX | Board **ESP32S3 Dev Module**, Flash 16MB, PSRAM **OPI PSRAM**. Muốn in Serial qua USB native thì bật *USB CDC On Boot* |
| FC | Board STM32F407 (STM32duino), *USB support* = **CDC (generic 'Serial' supersede U(S)ART)**, *U(S)ART support* = Enabled |

Code TX/RX có sẵn `#if ESP_ARDUINO_VERSION_MAJOR >= 3` để chạy được cả core ESP32 2.x và 3.x.

## Chạy thử lần đầu

> **Tháo cánh quạt hoặc rút pin motor khi thử.**

1. Nạp TX, RX, FC.
2. **Hiệu chuẩn cần** (làm 1 lần, lưu trong flash của TX): tắt nguồn TX, giữ cả hai nút ARM + MODE rồi bật nguồn. Bước 1: thả cần về giữa 4 giây. Bước 2: trong 8 giây xoay mỗi cần hết cỡ 4 góc, kéo ga hết lên xuống. Serial hiện `DA LUU hieu chuan`.
3. Cắm USB vào FC, mở Serial Monitor (cổng COM mới "USB Serial Device"). Mỗi 0,2 giây có một dòng trạng thái.
4. **Kiểm tra chiều cần:** đẩy lên / sang phải thì số tăng về 2000. Ngược thì đặt `REV_xxx = 1` trong `TX_ESP32.ino`. Cần ở giữa phải ra khoảng 1500, ga thấp nhất phải ra 1000.
5. **ARM:** giữ nút ARM 1 giây (ga đang thấp nhất). Nút MODE chuyển STAB và ALT.
6. **Thử mất sóng:** tắt TX, sau 0,5 giây FC báo mất sóng và motor về 1000.

Dòng trạng thái FC: `RX=OK/MAT` (có/mất khung CRSF), `CH[...]` (8 kênh, µs), `ARM`, `ALT`, góc R/P/Y, độ cao H, lệnh 4 ESC `M[...]`, `L=` (vòng lặp dài nhất, phải dưới 4,0 ms), `CRSF=a/b` (khung tốt / lỗi CRC).

---

## Xử lý sự cố

| Triệu chứng | Kiểm tra |
|---|---|
| TX báo `NO-LINK` mãi | RX có nguồn chưa. TX và RX cùng `RC_WIFI_CHANNEL`, `RC_USE_LR_MODE`, `RC_LINK_KEY`. Hai `RcProtocol.h` có giống nhau không. Trên RX xem bộ đếm `cb`, `badLen`, `badMagic`, `badCrc` để biết gói có tới hay không và sai ở đâu |
| FC báo `RX=MAT` dù RX đã `LINK` | Dây GPIO17 sang PA1 (không đấu nhầm), GND chung, `CRSF_BAUD` 420000 ở cả hai |
| `CRSF=…/N`, N tăng liên tục | Nhiễu dây UART: rút ngắn dây, GND chung chắc |
| Serial Monitor FC trắng | Sai cài đặt *USB support*, cáp USB chỉ sạc, hoặc thạch anh khác 8 MHz |
| Hiệu chuẩn cần báo LỖI | Kiểm tra 3V3/GND joystick, dùng chân ADC1, xoay đủ hành trình ở bước 2 |
| Ga từ chối ARM | Hạ ga xuống thấp nhất (hoặc để cần ga lò xo về giữa) |
| Windows: `'C:\Users\NGUYEN' is not recognized` khi nạp ESP32 | Tên user Windows có dấu cách làm hỏng bước link của ESP32 core 4.0.0. Dùng core 3.0.7, hoặc đặt project và dữ liệu Arduino ở đường dẫn không có dấu cách |

## Lưu ý an toàn

- Luôn tháo cánh quạt khi thử và hiệu chuẩn.
- Mặc định `DEBUG_USB 1` trên FC. Lần bay đầu hãy xem `L=` phải dưới 4,0 ms. Muốn chắc ăn khi bay thì đặt `DEBUG_USB 0`, và đặt `RX_DEBUG 0` trên RX. Khi bay không cắm USB.
- Mất sóng thì RX ngừng gửi khung, FC cắt motor sau `CRSF_TIMEOUT_MS` (500 ms), như máy thu ELRS thật.
- TX tự khởi động lại giữa chuyến bay (sụt nguồn) thì nút ARM về trạng thái thả và FC DISARM. Dùng pin TX tốt.
- `RC_USE_LR_MODE` mặc định 0 (WiFi thường). Bật 1 ở **cả hai phía** nếu cần tầm xa hơn, và thử ở độ cao thấp trước.
- Cần ga có lò xo: đặt `THROTTLE_SPRING` đúng loại cần. Đặt sai (cần không lò xo mà đặt 1) có thể làm ga tăng liên tục.
- Dự án tự chế, chưa có chứng nhận an toàn. Bay ở nơi thoáng, tránh người, và tự chịu trách nhiệm.

## Giấy phép

Chưa chọn. Thêm file `LICENSE` (ví dụ MIT) trước khi công khai.
