/* =====================================================================
 *  TX_ESP32.ino — TAY DIEU KHIEN (ESP32 thuong / ESP32-WROOM-32U)
 *
 *  2 joystick + vai nut -> ESP-NOW broadcast 100 goi/giay -> RX_ESP32S3
 *
 *  KENH GUI (khop FC_F405, xem Config.h cua FC):
 *    CH1 roll  CH2 pitch  CH3 ga  CH4 yaw  CH5 ARM  CH7 che do (STAB / giu do cao)
 *
 *  NUT BAM (noi giua chan GPIO va GND, da bat pull-up trong chip):
 *    ARM  : GIU 1 giay = ARM (chi khi ga o duoi cung), GIU 0.4 giay = DISARM (cat motor)
 *    MODE : bam 1 lan = doi STAB <-> ALT (giu do cao)
 *    TRIM : 4 nut tinh chinh roll/pitch, bam ca hai nut cua 1 truc = ve 0
 *  Giu ARM + MODE luc BAT NGUON = vao che do HIEU CHUAN can.
 *
 *  Arduino IDE: Board "ESP32 Dev Module", Serial Monitor 115200.
 *  Can 2 file cung thu muc: RcProtocol.h, TxLogic.h
 *
 *  CHI DUNG CHAN ADC1 cho can (32,33,34,35,36,39): ADC2 khong doc duoc
 *  khi WiFi/ESP-NOW dang chay.
 * ===================================================================== */

#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <Preferences.h>
#include <esp_mac.h>

/* ======================= CAU HINH CUA BAN ======================= */
// ---- chan can (ADC1). Mode 2: trai = ga + yaw, phai = pitch + roll ----
#define PIN_ROLL        32     // can phai, truc X
#define PIN_PITCH       33     // can phai, truc Y
#define PIN_THROTTLE    35     // can trai,  truc Y
#define PIN_YAW         34     // can trai,  truc X

// Dao chieu neu day can len ma gia tri xuong (kiem tra tren Serial Monitor).
// Chuan: can len / sang phai = gia tri LON (2000), giong tay EdgeTX da bay tot.
#define REV_ROLL        0
#define REV_PITCH       0
#define REV_THROTTLE    0
#define REV_YAW         0

// ---- loai can ga ----
//  0 = can ga KHONG co lo xo tu ve giua (de ga o dau thi o do)  <- mac dinh, an toan
//  1 = can ga co LO XO tu ve giua (joystick re tien): ga tang/giam dan khi day can
#define THROTTLE_SPRING 0
#define THR_RATE_US_PER_S 500.0f   // (lo xo) toc do tang ga khi day het can

// ---- nut bam (active-LOW, noi xuong GND). Dat -1 neu khong dung ----
#define PIN_BTN_ARM        25
#define PIN_BTN_MODE       26
#define PIN_TRIM_ROLL_L    27
#define PIN_TRIM_ROLL_R    14
#define PIN_TRIM_PITCH_UP  13
#define PIN_TRIM_PITCH_DN   4
#define PIN_LED             2   // den bao (-1 = khong co)

// ---- tinh chinh ----
#define SEND_HZ            100      // so goi/giay (50..250)
#define STICK_DEADBAND     0.04f    // vung chet o giua (yaw cua FC KHONG co deadband rieng -> can cai nay)
#define THR_SPRING_DEADBAND 0.08f   // vung chet cua can ga lo xo
#define THR_END_MARGIN     0.03f    // (ga khong lo xo) 3% hai dau luon ra 1000 / 2000
#define TRIM_STEP_US       5
#define TRIM_LIMIT_US      100

#define TX_DEBUG           1        // in trang thai ra Serial 5 lan/giay
#define TX_DEBUG_RAW       0        // 1 = in them gia tri ADC tho (de kiem tra day noi)
/* ================================================================ */

#include "RcProtocol.h"
#include "TxLogic.h"

static const uint8_t BCAST[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

static Preferences prefs;
static CalData     cal;
static bool        calibrated = false;
static int         trimRoll = 0, trimPitch = 0;
static bool        trimDirty = false;
static uint32_t    trimChangedMs = 0;

static TxState     st;
static Btn         bArm, bMode, bRL, bRR, bPU, bPD;
static TrimAxis    trRoll, trPitch;
static uint16_t    seqNo = 0;

static portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
static RcTelemPacket tlm;
static volatile uint32_t tlmMs = 0;

// ---------------------------------------------------------------------
static bool pinPressed(int pin) { return pin >= 0 && digitalRead(pin) == LOW; }

static int readAxisRaw(int pin) {
  int s = 0;
  for (int i = 0; i < 4; i++) s += analogRead(pin);
  return s / 4;
}

static void setDefaultCal(void) {
  cal.magic = CAL_MAGIC;
  for (int i = 0; i < 4; i++) { cal.ax[i].mn = 100; cal.ax[i].ct = 2048; cal.ax[i].mx = 4000; }
}

static void loadStored(void) {
  setDefaultCal();
  prefs.begin("rc", false);
  CalData tmp;
  size_t n = prefs.getBytes("cal", &tmp, sizeof(tmp));
  if (n == sizeof(tmp) && tmp.magic == CAL_MAGIC) { cal = tmp; calibrated = true; }
  trimRoll  = prefs.getShort("trR", 0);
  trimPitch = prefs.getShort("trP", 0);
  prefs.end();
}

static void saveTrim(void) {
  prefs.begin("rc", false);
  prefs.putShort("trR", (int16_t)trimRoll);
  prefs.putShort("trP", (int16_t)trimPitch);
  prefs.end();
}

static void led(bool on) { if (PIN_LED >= 0) digitalWrite(PIN_LED, on ? HIGH : LOW); }

// ---------------------------------------------------------------------
//  HIEU CHUAN (chay trong setup, giu ARM + MODE luc bat nguon)
// ---------------------------------------------------------------------
static void calibrateSticks(void) {
  const int pins[4] = { PIN_ROLL, PIN_PITCH, PIN_THROTTLE, PIN_YAW };
  const char *names[4] = { "ROLL", "PITCH", "GA", "YAW" };
  Serial.println();
  Serial.println("=== HIEU CHUAN CAN ===");
  Serial.println("Buoc 1/2: THA tat ca can ve GIUA (ga khong lo xo thi de ga o bat ky dau).");
  Serial.println("          Giu yen 4 giay...");

  long sum[4] = {0, 0, 0, 0};
  int  n = 0;
  uint32_t t0 = millis();
  while (millis() - t0 < 4000) {
    led(((millis() / 250) & 1) != 0);
    if (millis() - t0 > 2500) {
      for (int i = 0; i < 4; i++) sum[i] += readAxisRaw(pins[i]);
      n++;
    }
    delay(5);
  }
  int ct[4], mn[4], mx[4];
  for (int i = 0; i < 4; i++) { ct[i] = (int)(sum[i] / (n ? n : 1)); mn[i] = mx[i] = ct[i]; }

  Serial.println("Buoc 2/2: xoay moi can het co, cham 4 goc, ga keo het len xuong. 8 giay...");
  t0 = millis();
  while (millis() - t0 < 8000) {
    led(((millis() / 80) & 1) != 0);
    for (int i = 0; i < 4; i++) {
      int r = readAxisRaw(pins[i]);
      if (r < mn[i]) mn[i] = r;
      if (r > mx[i]) mx[i] = r;
    }
    delay(5);
  }
  led(false);

  bool ok = true;
  for (int i = 0; i < 4; i++) {
    bool needCenter = (i != 2) || (THROTTLE_SPRING != 0);
    bool bad = (mx[i] - mn[i] < 1200);
    if (needCenter && (ct[i] - mn[i] < 250 || mx[i] - ct[i] < 250)) bad = true;
    Serial.printf("  %-5s min=%4d giua=%4d max=%4d %s\n", names[i], mn[i], ct[i], mx[i], bad ? "<-- LOI" : "ok");
    if (bad) ok = false;
  }
  if (!ok) {
    Serial.println("HIEU CHUAN THAT BAI (hanh trinh qua ngan hoac tam lech). Khoi dong lai de thu lai.");
    Serial.println("Kiem tra: day 3.3V/GND cua joystick, chan ADC1, va xoay het co o buoc 2.");
    return;
  }
  cal.magic = CAL_MAGIC;
  for (int i = 0; i < 4; i++) { cal.ax[i].mn = (uint16_t)mn[i]; cal.ax[i].ct = (uint16_t)ct[i]; cal.ax[i].mx = (uint16_t)mx[i]; }
  prefs.begin("rc", false);
  prefs.putBytes("cal", &cal, sizeof(cal));
  prefs.end();
  calibrated = true;
  Serial.println("DA LUU hieu chuan. Co the ARM.");
}

// ---------------------------------------------------------------------
//  ESP-NOW
// ---------------------------------------------------------------------
#if ESP_ARDUINO_VERSION_MAJOR >= 3
static void onRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len)
#else
static void onRecv(const uint8_t *mac, const uint8_t *data, int len)
#endif
{
  if (len != (int)sizeof(RcTelemPacket)) return;
  RcTelemPacket t;
  memcpy(&t, data, sizeof(t));
  if (t.magic != RC_MAGIC_TELEM) return;
  if (t.crc != rcCrc((const uint8_t *)&t, sizeof(t) - 1)) return;
  t.mode[sizeof(t.mode) - 1] = 0;
  portENTER_CRITICAL(&mux);
  tlm = t;
  tlmMs = millis();
  portEXIT_CRITICAL(&mux);
}

static void radioInit(void) {
  WiFi.mode(WIFI_STA);

  uint8_t m[6];
  esp_read_mac(m, ESP_MAC_WIFI_STA);
  Serial.printf("MAC TX: %02X:%02X:%02X:%02X:%02X:%02X\n",
                m[0], m[1], m[2], m[3], m[4], m[5]);

  WiFi.disconnect();
  WiFi.setSleep(false);                  // khong ngu -> do tre thap
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(RC_WIFI_CHANNEL, WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_promiscuous(false);
#if RC_USE_LR_MODE

  esp_wifi_set_protocol(WIFI_IF_STA, WIFI_PROTOCOL_11B | WIFI_PROTOCOL_11G | WIFI_PROTOCOL_11N | WIFI_PROTOCOL_LR);
#endif
  WiFi.setTxPower(WIFI_POWER_19_5dBm);
  if (esp_now_init() != ESP_OK) {
    Serial.println("LOI: esp_now_init that bai");
    while (true) { led(true); delay(100); led(false); delay(100); }
  }
  esp_now_peer_info_t peer;
  memset(&peer, 0, sizeof(peer));
  memcpy(peer.peer_addr, BCAST, 6);
  peer.channel = 0;
  peer.ifidx = WIFI_IF_STA;
  peer.encrypt = false;
  esp_now_add_peer(&peer);
  esp_now_register_recv_cb(onRecv);
}

// ---------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println();
  Serial.println("TX_ESP32 khoi dong");

  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);
  const int ins[] = { PIN_BTN_ARM, PIN_BTN_MODE, PIN_TRIM_ROLL_L, PIN_TRIM_ROLL_R, PIN_TRIM_PITCH_UP, PIN_TRIM_PITCH_DN };
  for (unsigned i = 0; i < sizeof(ins) / sizeof(ins[0]); i++) if (ins[i] >= 0) pinMode(ins[i], INPUT_PULLUP);
  if (PIN_LED >= 0) pinMode(PIN_LED, OUTPUT);

  loadStored();
  txInit(st);

  if (pinPressed(PIN_BTN_ARM) && pinPressed(PIN_BTN_MODE)) calibrateSticks();
  if (!calibrated) {
    Serial.println("!! CHUA HIEU CHUAN CAN: tay se KHONG cho ARM.");
    Serial.println("   Tat nguon, giu ARM + MODE, bat nguon lai de hieu chuan.");
  }

  radioInit();
  Serial.printf("San sang. Kenh WiFi %d, %d goi/giay, ga %s.\n",
                RC_WIFI_CHANNEL, SEND_HZ, THROTTLE_SPRING ? "LO XO (tang dan)" : "KHONG lo xo (truc tiep)");
}

// ---------------------------------------------------------------------
static void ledUpdate(uint32_t ms, bool link) {
  bool on;
  if (!calibrated)      on = ((ms / 100) & 1) != 0;   // chop rat nhanh: chua hieu chuan
  else if (st.armed)    on = ((ms / 160) & 1) != 0;   // chop nhanh: DANG ARM
  else if (!link)       on = ((ms / 500) & 1) != 0;   // chop cham: chua nhan duoc telemetry tu RX
  else                  on = true;                    // sang lien tuc: co song, chua arm
  led(on);
}

static const char *eventText(uint8_t e) {
  switch (e) {
    case EV_ARMED:          return "ARMED";
    case EV_DISARMED:       return "DISARMED";
    case EV_REFUSED_NOCAL:  return "ARM bi tu choi: chua hieu chuan can";
    case EV_REFUSED_THR:    return "ARM bi tu choi: ha ga xuong het truoc";
    case EV_MODE_ALT:       return "Che do: ALT (giu do cao)";
    case EV_MODE_STAB:      return "Che do: STAB (tu can bang)";
    default:                return "";
  }
}

void loop() {
  static uint32_t lastUs = 0;
  static uint32_t lastPrintMs = 0;
  static uint8_t  printPhase = 0;

  uint32_t nowUs = micros();
  if ((uint32_t)(nowUs - lastUs) < (1000000UL / SEND_HZ)) return;
  float dt = (float)(uint32_t)(nowUs - lastUs) * 1e-6f;
  if (dt > 0.1f) dt = 0.1f;
  lastUs = nowUs;
  uint32_t nowMs = millis();

  // ---- doc can ----
  int rRoll  = readAxisRaw(PIN_ROLL);
  int rPitch = readAxisRaw(PIN_PITCH);
  int rThr   = readAxisRaw(PIN_THROTTLE);
  int rYaw   = readAxisRaw(PIN_YAW);

  TxIn in;
  in.roll   = axisNormCentered(rRoll,  cal.ax[0], REV_ROLL,  STICK_DEADBAND);
  in.pitch  = axisNormCentered(rPitch, cal.ax[1], REV_PITCH, STICK_DEADBAND);
  in.yaw    = axisNormCentered(rYaw,   cal.ax[3], REV_YAW,   STICK_DEADBAND);
  in.thr01  = axisNorm01(rThr, cal.ax[2], REV_THROTTLE, THR_END_MARGIN);
  in.thrCen = axisNormCentered(rThr, cal.ax[2], REV_THROTTLE, THR_SPRING_DEADBAND);

  // ---- nut ----
  in.btnArm  = btnDebounce(bArm,  pinPressed(PIN_BTN_ARM),  nowMs);
  in.btnMode = btnDebounce(bMode, pinPressed(PIN_BTN_MODE), nowMs);
  bool rl = btnDebounce(bRL, pinPressed(PIN_TRIM_ROLL_L),   nowMs);
  bool rr = btnDebounce(bRR, pinPressed(PIN_TRIM_ROLL_R),   nowMs);
  bool pu = btnDebounce(bPU, pinPressed(PIN_TRIM_PITCH_UP), nowMs);
  bool pd = btnDebounce(bPD, pinPressed(PIN_TRIM_PITCH_DN), nowMs);
  bool ch1 = trimUpdate(trRoll,  rl, rr, nowMs, trimRoll,  TRIM_STEP_US, TRIM_LIMIT_US);
  bool ch2 = trimUpdate(trPitch, pd, pu, nowMs, trimPitch, TRIM_STEP_US, TRIM_LIMIT_US);
  if (ch1 || ch2) { trimDirty = true; trimChangedMs = nowMs; }
  if (trimDirty && (nowMs - trimChangedMs) > 2000 && !st.armed) { saveTrim(); trimDirty = false; }
  in.trimRoll = trimRoll;
  in.trimPitch = trimPitch;
  in.calibrated = calibrated;

  // ---- logic + gui ----
  uint16_t ch[8];
  txStep(st, nowMs, dt, in, ch);

  RcCtrlPacket p;
  p.magic = RC_MAGIC_CTRL;
  p.seq = seqNo++;
  for (int i = 0; i < 8; i++) p.ch[i] = ch[i];
  p.crc = rcCrc((const uint8_t *)&p, sizeof(p) - 1);
  esp_now_send(BCAST, (const uint8_t *)&p, sizeof(p));

  // ---- su kien ----
  if (st.event != EV_NONE) {
    Serial.println(eventText(st.event));
    st.event = EV_NONE;
  }

  // ---- telemetry tu RX ----
  RcTelemPacket t;
  uint32_t tms;
  portENTER_CRITICAL(&mux);
  t = tlm; tms = tlmMs;
  portEXIT_CRITICAL(&mux);
  bool link = (tms != 0) && ((nowMs - tms) < 1000);

  ledUpdate(nowMs, link);

  // ---- in Serial: 5 lan/giay, xen ke dong kenh va dong FC (moi dong <120 ky tu) ----
#if TX_DEBUG
  if (nowMs - lastPrintMs >= 200) {
    lastPrintMs = nowMs;
    if ((printPhase++ & 1) == 0) {
      Serial.printf("CH %4u %4u %4u %4u | ARM=%d ALT=%d | trim R%+d P%+d | %s LQ=%u%%\n",
                    ch[0], ch[1], ch[2], ch[3], st.armed ? 1 : 0, st.alt ? 1 : 0,
                    trimRoll, trimPitch, link ? "LINK" : "NO-LINK", link ? t.lq : 0);
#if TX_DEBUG_RAW
      Serial.printf("RAW roll=%d pitch=%d thr=%d yaw=%d\n", rRoll, rPitch, rThr, rYaw);
#endif
    } else if (link && t.mode[0]) {
      Serial.printf("FC  P=%.1f R=%.1f Y=%d H=%.1fm Vz=%d %s\n",
                    t.pitch10 * 0.1f, t.roll10 * 0.1f, t.yaw10 / 10,
                    t.alt_dm * 0.1f, t.vario_cms, t.mode);
    }
  }
#endif
}
