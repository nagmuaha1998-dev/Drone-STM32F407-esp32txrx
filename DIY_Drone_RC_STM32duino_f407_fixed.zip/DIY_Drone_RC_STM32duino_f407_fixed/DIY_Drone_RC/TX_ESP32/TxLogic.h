/* =====================================================================
 *  TxLogic.h — LOGIC THUAN CUA TAY DIEU KHIEN (khong goi Arduino)
 *
 *  Tach rieng de test duoc tren may tinh. Gom:
 *    - chuan hoa can (hieu chuan, deadband, dao chieu)
 *    - chong rung nut, trim co lap lai
 *    - may trang thai ARM / che do bay / ga
 *
 *  Quy uoc kenh (khop FC_F405):
 *    ch[0] roll  ch[1] pitch  ch[2] ga  ch[3] yaw
 *    ch[4] ARM (>1500 = arm)     ch[6] che do (>1250 = giu do cao)
 * ===================================================================== */
#ifndef TX_LOGIC_H
#define TX_LOGIC_H

#include <stdint.h>
#include <math.h>

#ifndef THROTTLE_SPRING
#define THROTTLE_SPRING   0        // 0 = can ga KHONG lo xo; 1 = can ga tu ve giua
#endif
#ifndef THR_RATE_US_PER_S
#define THR_RATE_US_PER_S 500.0f   // (lo xo) ga tang/giam bao nhieu us/giay khi day het can
#endif
#ifndef THR_SPRING_MAX_US
#define THR_SPRING_MAX_US 1900.0f  // (lo xo) tran ga
#endif
#ifndef ALT_MIN_US
#define ALT_MIN_US        1100.0f  // (lo xo) o che do ALT khong cho ga <1100 de FC khong cat motor nham
#endif
#ifndef ARM_THR_MAX_US
#define ARM_THR_MAX_US    1050.0f  // chi cho ARM khi ga duoi muc nay (khop ARM_THROTTLE_MAX cua FC)
#endif
#ifndef ARM_HOLD_MS
#define ARM_HOLD_MS       1000     // giu nut ARM bao lau thi arm
#endif
#ifndef DISARM_HOLD_MS
#define DISARM_HOLD_MS    400      // giu nut ARM bao lau thi disarm (khan cap)
#endif
#define ALT_ENTRY_FRAMES  3        // (lo xo) so goi dau tien sau khi vao ALT mang gia tri ga "treo"

#define CAL_MAGIC 0xCA11B002u

struct AxisCal { uint16_t mn, ct, mx; };
struct CalData { uint32_t magic; AxisCal ax[4]; };   // 0 roll, 1 pitch, 2 ga, 3 yaw

static inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

// Can tu ve giua: -1..+1. Co deadband, phan con lai gian ra de van du hanh trinh.
static inline float axisNormCentered(int raw, const AxisCal &c, bool rev, float deadband) {
  float n;
  if (raw >= (int)c.ct) n = (c.mx > c.ct) ? (float)(raw - (int)c.ct) / (float)(c.mx - c.ct) : 0.0f;
  else                  n = (c.ct > c.mn) ? -(float)((int)c.ct - raw) / (float)(c.ct - c.mn) : 0.0f;
  n = clampf(n, -1.0f, 1.0f);
  if (rev) n = -n;
  float a = fabsf(n);
  if (a <= deadband) return 0.0f;
  a = (a - deadband) / (1.0f - deadband);
  return n > 0 ? a : -a;
}

// Can ga khong lo xo: 0..1 tu min den max, co le o hai dau de chac chan ra 1000 / 2000.
static inline float axisNorm01(int raw, const AxisCal &c, bool rev, float margin) {
  float n = (c.mx > c.mn) ? (float)(raw - (int)c.mn) / (float)(c.mx - c.mn) : 0.0f;
  n = clampf(n, 0.0f, 1.0f);
  if (rev) n = 1.0f - n;
  n = (n - margin) / (1.0f - 2.0f * margin);
  return clampf(n, 0.0f, 1.0f);
}

// ---------- chong rung nut ----------
struct Btn { bool state; bool last; uint32_t t; };
static inline bool btnDebounce(Btn &b, bool raw, uint32_t nowMs) {
  if (raw != b.last) { b.last = raw; b.t = nowMs; }
  else if ((uint32_t)(nowMs - b.t) >= 20) b.state = raw;
  return b.state;
}

// ---------- trim: bam 1 lan = 1 buoc, giu >0.5s thi lap lai, bam ca 2 nut = ve 0 ----------
struct RepBtn { bool prev; uint32_t tNext; };
static inline bool repFire(RepBtn &r, bool down, uint32_t nowMs) {
  if (!down) { r.prev = false; return false; }
  if (!r.prev) { r.prev = true; r.tNext = nowMs + 500; return true; }
  if ((int32_t)(nowMs - r.tNext) >= 0) { r.tNext = nowMs + 100; return true; }
  return false;
}
struct TrimAxis { RepBtn dec, inc; bool bothPrev; };
static inline bool trimUpdate(TrimAxis &a, bool dec, bool inc, uint32_t nowMs, int &trim, int step, int lim) {
  int old = trim;
  if (dec && inc) {
    if (!a.bothPrev) trim = 0;
    a.bothPrev = true;
    a.dec.prev = a.inc.prev = true;
    a.dec.tNext = a.inc.tNext = nowMs + 500;
    return trim != old;
  }
  a.bothPrev = false;
  if (repFire(a.dec, dec, nowMs)) trim -= step;
  if (repFire(a.inc, inc, nowMs)) trim += step;
  if (trim >  lim) trim =  lim;
  if (trim < -lim) trim = -lim;
  return trim != old;
}

// ---------- may trang thai ----------
struct TxIn {
  float roll, pitch, yaw;      // -1..+1 (da deadband, da dao chieu)
  float thr01;                 // 0..1   (ga khong lo xo)
  float thrCen;                // -1..+1 (ga lo xo)
  bool  btnArm, btnMode;       // da chong rung
  bool  calibrated;
  int   trimRoll, trimPitch;   // us
};

enum TxEvent : uint8_t {
  EV_NONE = 0, EV_ARMED, EV_DISARMED, EV_REFUSED_NOCAL, EV_REFUSED_THR, EV_MODE_ALT, EV_MODE_STAB
};

struct TxState {
  bool     armed, alt;
  bool     armDown, armActed, modeDown;
  uint8_t  altEntry;
  uint32_t armDownAt;
  float    thrAcc;             // (lo xo) gia tri ga tich luy
  uint8_t  event;              // TxEvent, noi goi doc xong thi dat ve EV_NONE
};

static inline void txInit(TxState &s) {
  s.armed = false; s.alt = false;
  s.armDown = true; s.armActed = true; s.modeDown = true;   // nut dang giu luc bat nguon phai nha ra truoc
  s.altEntry = 0; s.armDownAt = 0; s.thrAcc = 1000.0f; s.event = EV_NONE;
}

static inline uint16_t usClamp(float v) {
  if (v < 1000.0f) v = 1000.0f;
  if (v > 2000.0f) v = 2000.0f;
  return (uint16_t)(v + 0.5f);
}

static inline void txStep(TxState &s, uint32_t nowMs, float dt, const TxIn &in, uint16_t ch[8]) {
  // ---- nut che do: nhan 1 lan = doi STAB <-> ALT ----
  if (in.btnMode) {
    if (!s.modeDown) {
      s.modeDown = true;
      s.alt = !s.alt;
      s.altEntry = s.alt ? ALT_ENTRY_FRAMES : 0;
      s.event = s.alt ? EV_MODE_ALT : EV_MODE_STAB;
    }
  } else s.modeDown = false;

  // ---- ga hien tai co thap khong (de xet ARM) ----
#if THROTTLE_SPRING
  bool thrLow = (s.thrAcc < ARM_THR_MAX_US) && (in.thrCen < 0.2f);   // phai tha can ga ve giua moi cho ARM
#else
  bool thrLow = (1000.0f + in.thr01 * 1000.0f) < ARM_THR_MAX_US;
#endif

  // ---- nut ARM: giu ARM_HOLD_MS de arm, giu DISARM_HOLD_MS de disarm ----
  if (in.btnArm) {
    if (!s.armDown) { s.armDown = true; s.armDownAt = nowMs; s.armActed = false; }
    if (!s.armActed) {
      uint32_t held = nowMs - s.armDownAt;
      if (s.armed) {
        if (held >= DISARM_HOLD_MS) {
          s.armed = false; s.armActed = true; s.thrAcc = 1000.0f; s.event = EV_DISARMED;
        }
      } else if (held >= ARM_HOLD_MS) {
        s.armActed = true;                       // du thanh cong hay bi tu choi cung khong lap lai den khi nha nut
        if (!in.calibrated)  s.event = EV_REFUSED_NOCAL;
        else if (!thrLow)    s.event = EV_REFUSED_THR;
        else {
          s.armed = true; s.alt = false; s.altEntry = 0; s.thrAcc = 1000.0f;   // luon cat canh o STAB
          s.event = EV_ARMED;
        }
      }
    }
  } else {
    s.armDown = false;
  }

  // ---- ga ----
  float thrOut;
#if THROTTLE_SPRING
  if (!s.armed) s.thrAcc = 1000.0f;
  else if (!s.alt) {
    s.thrAcc += in.thrCen * THR_RATE_US_PER_S * dt;
    s.thrAcc = clampf(s.thrAcc, 1000.0f, THR_SPRING_MAX_US);
  }
  if (!s.alt || s.altEntry > 0) thrOut = s.thrAcc;                    // STAB, hoac vai goi dau cua ALT: FC lay gia tri nay lam ga treo
  else thrOut = clampf(1500.0f + in.thrCen * 500.0f, ALT_MIN_US, 2000.0f);   // ALT: can = leo/ha
#else
  thrOut = 1000.0f + in.thr01 * 1000.0f;
#endif
  if (s.altEntry > 0) s.altEntry--;

  ch[0] = usClamp(1500.0f + in.roll  * 500.0f + (float)in.trimRoll);
  ch[1] = usClamp(1500.0f + in.pitch * 500.0f + (float)in.trimPitch);
  ch[2] = usClamp(thrOut);
  ch[3] = usClamp(1500.0f + in.yaw   * 500.0f);
  ch[4] = s.armed ? 2000 : 1000;
  ch[5] = 1000;
  ch[6] = s.alt ? 2000 : 1000;
  ch[7] = 1000;
}

#endif
