/* =====================================================================
 *  Crsf.h — RX GIA LAP MAY THU ELRS: dong goi CRSF gui FC + doc telemetry FC
 *
 *  Khop 100% voi CRSF.ino cua FC_F405:
 *    goi RC  : [0xC8][24][0x16][22 byte = 16 kenh x 11 bit][crc8 0xD5]
 *    FC doc kenh dai 1000-2000us:  us = 1000 + (v - 172) * 1000 / 1639
 *    nen o day:                    v  = 172  + (us - 1000) * 1639 / 1000
 *    (1000->172, 1500->992, 2000->1811)
 *
 *  Telemetry FC gui ve (PA0 -> chan RX cua ESP32):
 *    0x1E tu the (pitch, roll, yaw: rad*10000, big-endian)
 *    0x09 do cao baro      0x07 vario (cm/s)     0x21 chuoi che do bay
 *
 *  File khong goi Arduino -> test duoc tren may tinh.
 * ===================================================================== */
#ifndef RX_CRSF_H
#define RX_CRSF_H

#include <stdint.h>
#include <string.h>
#include <math.h>

#ifndef CRSF_SYNC
#define CRSF_SYNC     0xC8
#endif
#ifndef CRSF_TYPE_RC
#define CRSF_TYPE_RC  0x16
#endif

static inline uint8_t crsfCrc8(const uint8_t *p, uint8_t len) {
  uint8_t crc = 0;
  for (uint8_t i = 0; i < len; i++) {
    crc ^= p[i];
    for (uint8_t b = 0; b < 8; b++)
      crc = (crc & 0x80) ? (uint8_t)((crc << 1) ^ 0xD5) : (uint8_t)(crc << 1);
  }
  return crc;
}

// us[16] (1000..2000) -> khung CRSF 26 byte. Tra ve 26.
static inline uint8_t crsfBuildRc(uint8_t *f, const uint16_t us[16]) {
  uint32_t bits = 0;
  uint8_t  nb = 0, idx = 3;
  f[0] = CRSF_SYNC;
  f[1] = 24;                 // type + 22 payload + crc
  f[2] = CRSF_TYPE_RC;
  for (uint8_t c = 0; c < 16; c++) {
    uint16_t u = us[c];
    if (u < 1000) u = 1000;
    if (u > 2000) u = 2000;
    uint32_t v = 172u + (((uint32_t)(u - 1000) * 1639u + 500u) / 1000u);
    bits |= v << nb;
    nb += 11;
    while (nb >= 8) { f[idx++] = (uint8_t)(bits & 0xFF); bits >>= 8; nb -= 8; }
  }
  f[25] = crsfCrc8(&f[2], 23);
  return 26;
}

// ---------------------------------------------------------------------
//  Doc telemetry tu FC
// ---------------------------------------------------------------------
struct FcTelem {
  int16_t  pitch10, roll10, yaw10;   // 0.1 do
  int16_t  alt_dm;                   // 0.1 m
  int16_t  vario_cms;
  char     mode[14];
  uint32_t lastMs;                   // luc nhan goi gan nhat tu FC
};

struct CrsfRxParser { uint8_t buf[64]; uint8_t idx; uint8_t len; };

static inline int16_t crsfBe16(const uint8_t *p) { return (int16_t)(((uint16_t)p[0] << 8) | p[1]); }
// rad*10000 -> 0.1 do:  v/10000 * 57.29578 * 10 = v * 0.0572958
static inline int16_t crsfRad10000ToDeg10(int16_t v) { return (int16_t)lroundf((float)v * 0.0572958f); }

static inline void crsfHandleFcFrame(const uint8_t *f, FcTelem &t, uint32_t nowMs) {
  uint8_t type = f[2];
  uint8_t plen = (uint8_t)(f[1] - 2);
  const uint8_t *p = &f[3];
  switch (type) {
    case 0x1E:
      if (plen >= 6) {
        t.pitch10 = crsfRad10000ToDeg10(crsfBe16(&p[0]));
        t.roll10  = crsfRad10000ToDeg10(crsfBe16(&p[2]));
        t.yaw10   = crsfRad10000ToDeg10(crsfBe16(&p[4]));
      }
      break;
    case 0x09:
      if (plen >= 2) {
        uint16_t pk = (uint16_t)crsfBe16(p);
        int32_t dm = (pk & 0x8000) ? (int32_t)(pk & 0x7FFF) * 10 : (int32_t)pk - 10000;
        if (dm > 32767) dm = 32767;
        if (dm < -32768) dm = -32768;
        t.alt_dm = (int16_t)dm;
      }
      break;
    case 0x07:
      if (plen >= 2) t.vario_cms = crsfBe16(p);
      break;
    case 0x21: {
      uint8_t n = 0;
      while (n < plen && n < sizeof(t.mode) - 1 && p[n] != 0) { t.mode[n] = (char)p[n]; n++; }
      t.mode[n] = 0;
      break;
    }
    default: return;
  }
  t.lastMs = nowMs;
}

static inline void crsfRxFeed(CrsfRxParser &ps, FcTelem &t, uint8_t c, uint32_t nowMs) {
  if (ps.idx == 0) {
    if (c != CRSF_SYNC) return;
    ps.buf[ps.idx++] = c;
  } else if (ps.idx == 1) {
    if (c < 2 || c > 62) { ps.idx = 0; return; }
    ps.len = c;
    ps.buf[ps.idx++] = c;
  } else {
    ps.buf[ps.idx++] = c;
    if (ps.idx == (uint8_t)(ps.len + 2)) {
      if (crsfCrc8(&ps.buf[2], (uint8_t)(ps.len - 1)) == ps.buf[ps.len + 1])
        crsfHandleFcFrame(ps.buf, t, nowMs);
      ps.idx = 0;
    }
  }
}

#endif
