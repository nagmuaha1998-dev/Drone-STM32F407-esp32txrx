/* =====================================================================
 *  RX_ESP32S3.ino — MACH THU TREN DRONE (ESP32-S3 N16R8)
 *
 *  Nhan ESP-NOW tu TX_ESP32  ->  xuat CRSF 420000 baud cho FC_F405
 *  (giong het mot may thu ELRS, nen FC KHONG phai sua phan nhan).
 *  Dong thoi doc telemetry FC gui ve va chuyen cho tay (in tren Serial).
 *
 *  DAY NOI (CHEO TX/RX, bat buoc chung GND):
 *      ESP32-S3 GPIO17 (TX)  ->  FC PA1   (CRSF_PIN_RX cua FC)
 *      ESP32-S3 GPIO18 (RX)  <-  FC PA0   (CRSF_PIN_TX cua FC, telemetry)
 *      ESP32-S3 GND          --  FC GND
 *      ESP32-S3 5V           <-  5V cua FC/BEC (KHONG cap tu chan 3.3V cua FC)
 *
 *  GPIO 26..37 tren ESP32-S3 N16R8 dung cho flash/PSRAM octal: KHONG dung.
 *
 *  Arduino IDE: Board "ESP32S3 Dev Module", Flash 16MB, PSRAM "OPI PSRAM".
 *  Can 2 file cung thu muc: RcProtocol.h, Crsf.h
 *
 *  MAT SONG: RX ngung gui khung CRSF -> FC tu vao failsafe sau
 *  CRSF_TIMEOUT_MS (500ms) va cat motor — dung nhu may thu ELRS that.
 * ===================================================================== */

#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <esp_mac.h>

/* ======================= CAU HINH ======================= */
#define PIN_FC_TX        17        // -> PA1 cua FC
#define PIN_FC_RX        18        // <- PA0 cua FC
#define CRSF_BAUD        420000    // phai bang CRSF_BAUD trong Config.h cua FC
#define LINK_TIMEOUT_MS  300       // khong co goi nao trong ngan nay = mat song (chi de bao den)
#define TELEM_PERIOD_MS  100       // gui telemetry ve tay 10 lan/giay
#define RX_DEBUG         1         // in trang thai 1 lan/giay. Dat 0 khi lap len drone neu khong can
#define LED_LINK_PIN     4         // LED xanh ngoai: co song (qua tro 220-330 ohm xuong GND)
#define LED_LOST_PIN     5         // LED do ngoai: mat song
/* ======================================================== */

#include "RcProtocol.h"
#include "Crsf.h"

//static const uint8_t BCAST[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
static const uint8_t txMac[6] = {0x70, 0x4B, 0xCA, 0x10, 0xA3, 0xD4};

static portMUX_TYPE   mux = portMUX_INITIALIZER_UNLOCKED;
static RcCtrlPacket   pend;
static volatile bool  pendNew = false;
static volatile uint32_t badPkts = 0;
static volatile uint32_t cbCount = 0;    // so lan callback ESP-NOW duoc goi (moi goi toi RX)
static volatile uint32_t badLen = 0;     // sai do dai goi
static volatile uint32_t badMagic = 0;   // sai magic
static volatile int      lastLen = 0;    // do dai goi cuoi cung nhan duoc

static FcTelem        fcT;
static CrsfRxParser   fcP;

static uint32_t lastRxMs = 0;
static uint32_t framesSent = 0;
static uint16_t chNow[16];

// thong ke chat luong lien ket
static bool     haveSeq = false;
static uint16_t lastSeq = 0;
static uint32_t winStartMs = 0, winRx = 0, winExp = 0;
static uint8_t  lq = 0;
static uint32_t pps = 0;

// ---------------------------------------------------------------------
#if ESP_ARDUINO_VERSION_MAJOR >= 3
static void onRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len)
#else
static void onRecv(const uint8_t *mac, const uint8_t *data, int len)
#endif
{
  cbCount++;
  lastLen = len;
  if (len != (int)sizeof(RcCtrlPacket)) { badLen++; return; }
  RcCtrlPacket p;
  memcpy(&p, data, sizeof(p));
  if (p.magic != RC_MAGIC_CTRL) { badMagic++; return; }
  if (p.crc != rcCrc((const uint8_t *)&p, sizeof(p) - 1)) { badPkts++; return; }
  portENTER_CRITICAL(&mux);
  pend = p;
  pendNew = true;
  portEXIT_CRITICAL(&mux);
}

static void radioInit(void) {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  WiFi.setSleep(false);
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(RC_WIFI_CHANNEL, WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_promiscuous(false);
#if RC_USE_LR_MODE
  esp_wifi_set_protocol(WIFI_IF_STA, WIFI_PROTOCOL_11B | WIFI_PROTOCOL_11G | WIFI_PROTOCOL_11N | WIFI_PROTOCOL_LR);
#endif
  WiFi.setTxPower(WIFI_POWER_19_5dBm);
  if (esp_now_init() != ESP_OK) {
    Serial.println("LOI: esp_now_init that bai");
    while (true) delay(1000);
  }
  esp_now_peer_info_t peer;
  memset(&peer, 0, sizeof(peer));
  memcpy(peer.peer_addr, txMac, 6);
  peer.channel = 0;
  peer.ifidx = WIFI_IF_STA;
  peer.encrypt = false;
  if (esp_now_add_peer(&peer) != ESP_OK) Serial.println("CANH BAO: add peer TX that bai");
  esp_now_register_recv_cb(onRecv);

  uint8_t m[6];
  esp_read_mac(m, ESP_MAC_WIFI_STA);
  uint8_t ch; wifi_second_chan_t sc;
  esp_wifi_get_channel(&ch, &sc);
  Serial.printf("MAC RX: %02X:%02X:%02X:%02X:%02X:%02X | kenh thuc te: %u | LR mode: %d | sizeof(RcCtrlPacket)=%u\n",
                m[0], m[1], m[2], m[3], m[4], m[5], ch, (int)RC_USE_LR_MODE, (unsigned)sizeof(RcCtrlPacket));
}

static void rxLed(bool link) {
  static int8_t last = -1;
  int8_t v = link ? 1 : 0;
  if (v == last) return;
  last = v;
  digitalWrite(LED_LINK_PIN, link ? HIGH : LOW);
  digitalWrite(LED_LOST_PIN, link ? LOW : HIGH);
}

// Dem goi nhan duoc / goi mong doi de ra % chat luong. Tra ve false neu goi trung.
static bool statsOnPacket(uint16_t seq) {
  if (!haveSeq) { haveSeq = true; lastSeq = seq; winRx++; winExp++; return true; }
  uint16_t d = (uint16_t)(seq - lastSeq);
  if (d == 0) return false;
  if (d > 100) d = 1;              // nhay lon (TX khoi dong lai) -> tinh la 1
  lastSeq = seq;
  winRx++;
  winExp += d;
  return true;
}

static void sendTelemToTx(void) {
  RcTelemPacket t;
  memset(&t, 0, sizeof(t));
  t.magic = RC_MAGIC_TELEM;
  t.lq = lq;
  bool fcAlive = (fcT.lastMs != 0) && ((millis() - fcT.lastMs) < 1500);
  if (fcAlive) {
    t.pitch10 = fcT.pitch10;  t.roll10 = fcT.roll10;  t.yaw10 = fcT.yaw10;
    t.alt_dm = fcT.alt_dm;    t.vario_cms = fcT.vario_cms;
    strncpy(t.mode, fcT.mode, sizeof(t.mode) - 1);
    if (t.mode[0] == 0) t.mode[0] = '?';
  }
  t.crc = rcCrc((const uint8_t *)&t, sizeof(t) - 1);
  esp_now_send(txMac, (const uint8_t *)&t, sizeof(t));
}

// ---------------------------------------------------------------------
void setup() {
  pinMode(LED_LINK_PIN, OUTPUT);
  pinMode(LED_LOST_PIN, OUTPUT);
  Serial.begin(115200);
#if defined(ARDUINO_USB_CDC_ON_BOOT) && ARDUINO_USB_CDC_ON_BOOT
  Serial.setTxTimeoutMs(0);        // khong co may tinh cam thi KHONG duoc ket o Serial.print
#endif
  delay(200);

  Serial1.setRxBufferSize(256);
  Serial1.begin(CRSF_BAUD, SERIAL_8N1, PIN_FC_RX, PIN_FC_TX);

  for (int i = 0; i < 16; i++) chNow[i] = 1500;
  memset(&fcT, 0, sizeof(fcT));
  memset(&fcP, 0, sizeof(fcP));

  radioInit();
  rxLed(false);
  Serial.printf("RX_ESP32S3 san sang. CRSF %d baud tren GPIO%d(TX)/GPIO%d(RX), kenh WiFi %d\n",
                CRSF_BAUD, PIN_FC_TX, PIN_FC_RX, RC_WIFI_CHANNEL);
}

void loop() {
  uint32_t now = millis();

  // ---- 1. co goi dieu khien moi -> doi ra CRSF gui FC ngay ----
  RcCtrlPacket p;
  bool have = false;
  portENTER_CRITICAL(&mux);
  if (pendNew) { p = pend; pendNew = false; have = true; }
  portEXIT_CRITICAL(&mux);

  if (have && statsOnPacket(p.seq)) {
    lastRxMs = now;
    for (int i = 0; i < 8; i++) chNow[i] = p.ch[i];
    // chNow[8..15] giu 1500
    uint8_t f[26];
    uint8_t n = crsfBuildRc(f, chNow);
    Serial1.write(f, n);
    framesSent++;
  }

  bool link = (lastRxMs != 0) && ((now - lastRxMs) < LINK_TIMEOUT_MS);

  // ---- 2. doc telemetry tu FC ----
  while (Serial1.available()) crsfRxFeed(fcP, fcT, (uint8_t)Serial1.read(), now);

  // ---- 3. thong ke 1 giay ----
  if (now - winStartMs >= 1000) {
    winStartMs = now;
    lq = winExp ? (uint8_t)((winRx * 100UL / winExp) > 100 ? 100 : (winRx * 100UL / winExp)) : 0;
    pps = winRx;
    winRx = winExp = 0;
#if RX_DEBUG
    Serial.printf("[RX] %s %u pkt/s LQ=%u%% | cb=%u badLen=%u badMagic=%u badCrc=%u lastLen=%d | CH %u %u %u %u A%u M%u\n",
                  link ? "LINK" : "MAT-SONG", (unsigned)pps, (unsigned)lq,
                  (unsigned)cbCount, (unsigned)badLen, (unsigned)badMagic, (unsigned)badPkts, (int)lastLen,
                  chNow[0], chNow[1], chNow[2], chNow[3], chNow[4], chNow[6]);
    if (fcT.lastMs && (now - fcT.lastMs) < 1500)
      Serial.printf("[FC] P=%.1f R=%.1f Y=%d H=%.1fm %s\n",
                    fcT.pitch10 * 0.1f, fcT.roll10 * 0.1f, fcT.yaw10 / 10, fcT.alt_dm * 0.1f, fcT.mode);
    else
      Serial.println("[FC] chua nhan telemetry (kiem tra day PA0 -> GPIO18)");
#endif
  }

  // ---- 4. gui telemetry ve tay (chi khi dang co song) ----
  static uint32_t lastTelemMs = 0;
  if (link && (now - lastTelemMs) >= TELEM_PERIOD_MS) {
    lastTelemMs = now;
    sendTelemToTx();
  }

  rxLed(link);
}
