/* =====================================================================
 *  RcProtocol.h — GOI TIN GIUA TAY (TX) VA MACH THU (RX)
 *
 *  !!! FILE NAY PHAI GIONG HET o hai thu muc TX_ESP32 va RX_ESP32S3 !!!
 *  (sua o dau thi chep sang cho kia)
 *
 *  Dung ESP-NOW kieu BROADCAST (khong can biet dia chi MAC, khong cho
 *  ACK nen khong bao gio bi ket hang doi khi mat song).
 *  Chong nhieu cheo giua nhieu bo: moi goi duoc CRC8 co "hat giong"
 *  RC_LINK_KEY. Khac key -> CRC sai -> bi bo. Muon 2 drone bay gan nhau
 *  thi dat 2 key khac nhau.
 * ===================================================================== */
#ifndef RC_PROTOCOL_H
#define RC_PROTOCOL_H

#include <stdint.h>
#include <stddef.h>

#define RC_LINK_KEY      0x4B31     // doi neu bay nhieu bo gan nhau
#define RC_WIFI_CHANNEL  1          // 1..13, ca hai phia phai giong nhau
#define RC_USE_LR_MODE   0          // 1 = che do tam xa ESP32<->ESP32 (cham hon, xa hon). Hai phia giong nhau.

#define RC_MAGIC_CTRL    0xA5
#define RC_MAGIC_TELEM   0x5A

// TX -> RX : 8 kenh, don vi micro-giay 1000..2000
struct __attribute__((packed)) RcCtrlPacket {
  uint8_t  magic;
  uint16_t seq;
  uint16_t ch[8];     // 0 roll, 1 pitch, 2 ga, 3 yaw, 4 ARM, 5 aux1, 6 che do bay, 7 aux2
  uint8_t  crc;
};

// RX -> TX : so lieu tu FC chuyen ve (de in tren Serial Monitor cua tay)
struct __attribute__((packed)) RcTelemPacket {
  uint8_t  magic;
  uint8_t  lq;        // % goi dieu khien RX nhan duoc trong 1 giay gan nhat
  int16_t  pitch10;   // 0.1 do
  int16_t  roll10;
  int16_t  yaw10;
  int16_t  alt_dm;    // 0.1 m (so voi luc bat nguon FC)
  int16_t  vario_cms; // cm/s
  char     mode[14];  // "STAB*", "ALT L3.6" ... rong = FC chua gui telemetry
  uint8_t  crc;
};

static inline uint8_t rcCrcByte(uint8_t crc, uint8_t b) {
  crc ^= b;
  for (uint8_t i = 0; i < 8; i++)
    crc = (crc & 0x80) ? (uint8_t)((crc << 1) ^ 0xD5) : (uint8_t)(crc << 1);
  return crc;
}

// CRC8 (da thuc 0xD5) bat dau bang 2 byte cua RC_LINK_KEY
static inline uint8_t rcCrc(const uint8_t *p, size_t n) {
  uint8_t crc = rcCrcByte(0, (uint8_t)(RC_LINK_KEY & 0xFF));
  crc = rcCrcByte(crc, (uint8_t)(RC_LINK_KEY >> 8));
  for (size_t i = 0; i < n; i++) crc = rcCrcByte(crc, p[i]);
  return crc;
}

#endif
