DIY DRONE RC — TAY ESP32 (TX) + MẠCH THU ESP32-S3 (RX) + SỬA USB COM CHO FC_F405
=====================================================================================

SƠ ĐỒ
-----
  [ESP32 TX]  --ESP-NOW (WiFi 2.4GHz, 100 gói/giây)-->  [ESP32-S3 RX]  --CRSF 420000 baud-->  [STM32F407 FC]
   2 joystick                                            giả lập máy thu ELRS                 (code FC_F405 cũ)
   + nút bấm        <--telemetry 10 lần/giây (tuỳ chọn)--  đọc telemetry FC gửi ra PA0

  RX nói chuyện với FC y như một máy thu ELRS nên FC KHÔNG phải sửa phần nhận.
  (Phần FC chỉ sửa thêm để xem Serial Monitor qua cổng USB COM.)

THƯ MỤC
-------
  TX_ESP32/     TX_ESP32.ino  RcProtocol.h  TxLogic.h      -> nạp cho ESP32 (tay)
  RX_ESP32S3/   RX_ESP32S3.ino  RcProtocol.h  Crsf.h       -> nạp cho ESP32-S3 (trên drone)
  FC_F405/      bản FC của bạn + tab mới Debug.ino         -> nạp cho STM32F407
  * RcProtocol.h ở TX và RX PHẢI GIỐNG HỆT NHAU (sửa chỗ nào thì chép sang chỗ kia).
  * Mỗi thư mục là 1 sketch riêng, mở file .ino cùng tên thư mục bằng Arduino IDE.


1) ĐẤU DÂY
----------
RX (ESP32-S3 N16R8)  <->  FC (STM32F407)        [UART CHÉO, BẮT BUỘC CHUNG GND]
    GPIO17 (TX)   ->   PA1   (CRSF_PIN_RX của FC)
    GPIO18 (RX)   <-   PA0   (CRSF_PIN_TX của FC, để nhận telemetry)
    GND           --   GND
    5V            <-   5V của FC/BEC (đừng cấp từ chân 3.3V của FC)
  Không dùng GPIO 26..37 trên S3 N16R8 (flash/PSRAM octal).

TX (ESP32) mặc định (đổi ở đầu file TX_ESP32.ino):
    Cần phải X (roll) = GPIO32     Cần phải Y (pitch) = GPIO33
    Cần trái Y (ga)   = GPIO35     Cần trái X (yaw)   = GPIO34
        (chỉ dùng chân ADC1; ADC2 không đọc được khi đang bật WiFi)
        mỗi joystick: VCC -> 3V3, GND -> GND (đừng cấp 5V vào chân ADC)
    Nút (một đầu nối GND, đầu kia nối chân, đã bật pull-up trong chip):
        ARM = GPIO25     MODE = GPIO26
        Trim roll  trái/phải = GPIO27 / GPIO14
        Trim pitch lên/xuống = GPIO13 / GPIO4
    LED báo = GPIO2 (đặt -1 nếu không có)


2) CÀI ĐẶT ARDUINO IDE
----------------------
TX  : Board "ESP32 Dev Module".   Serial Monitor 115200.
RX  : Board "ESP32S3 Dev Module", Flash 16MB, PSRAM "OPI PSRAM".
      Nếu in Serial qua cổng USB native: "USB CDC On Boot" = Enabled.
FC  : Board STM32F407 như bạn đang dùng, và QUAN TRỌNG cho USB COM, menu Tools:
          USB support (if available) = CDC (generic 'Serial' supersede U(S)ART)
          U(S)ART support            = Enabled (generic 'Serial')
      Nếu thấy cảnh báo "Serial KHÔNG phải USB COM" lúc biên dịch tức là
      đang chọn sai mục này.


3) CHẠY THỬ LẦN ĐẦU  (THÁO CÁNH QUẠT hoặc không cắm pin motor!)
---------------------------------------------------------------
  a. Nạp TX, RX, FC.
  b. Hiệu chuẩn cần (chỉ làm 1 lần, lưu trong flash của TX):
       - Tắt nguồn TX. GIỮ cả 2 nút ARM + MODE rồi bật nguồn.
       - Bước 1: thả hết cần về giữa 4 giây (nếu cần ga không có lò xo thì để ga ở đâu cũng được).
       - Bước 2: trong 8 giây xoay mỗi cần hết cỡ 4 góc; ga kéo hết lên xuống.
       - Serial Monitor TX hiện "DA LUU hieu chuan".
     Chưa hiệu chuẩn thì TX từ chối ARM, LED chớp rất nhanh.
  c. Cắm USB vào FC, mở Serial Monitor (cổng COM mới "USB Serial Device").
     Sẽ thấy banner rồi mỗi 0,2 giây một dòng, ví dụ:
        t=12.3 RX=OK CH[1500 1500 1000 1500 1000 1000 1000 1000] ARM=0 ALT=0
        R=0.4 P=-0.2 Y=3.1 H=0.0m Vz=0 M[1000 1000 1000 1000] L=3.1ms CRSF=1234/0
  d. KIỂM TRA CHIỀU CẦN trên dòng đó (chuẩn: đẩy cần lên/sang phải = số TĂNG về 2000):
       cần phải sang phải -> CH1 tăng      cần phải đẩy lên -> CH2 tăng
       cần trái đẩy lên   -> CH3 tăng      cần trái sang phải -> CH4 tăng
     Ngược thì đặt REV_xxx = 1 trong TX_ESP32.ino rồi nạp lại.
     Để cần ở giữa phải ra ~1500, ga thấp nhất phải ra 1000 (FC chỉ cho ARM khi ga < 1050).
  e. ARM: GIỮ nút ARM 1 giây (chỉ được khi ga đang ở thấp nhất).
        FC dòng hiện ARM=1.  Giữ nút ARM 0,4 giây = DISARM ngay (dùng làm nút dừng khẩn).
     Nút MODE: bấm 1 lần = STAB <-> ALT (CH7 chuyển 1000 <-> 2000, ALT=1 trên FC).
     Mỗi lần ARM, TX tự ép về STAB (cất cánh ở STAB rồi mới bật ALT).
  f. Thử mất sóng: tắt TX -> sau 0,5 s FC hiện RX=MAT và motor về 1000.


4) ĐỌC DÒNG TRẠNG THÁI CỦA FC
-----------------------------
  RX=OK/MAT   có/mất khung CRSF       CH[...]  8 kênh đầu (µs)
  ARM / ALT   trạng thái trong FC     R P Y    góc (độ)
  H, Vz       độ cao (m), vận tốc đứng (cm/s)
  M[...]      lệnh 4 ESC (1000 = tắt)
  L=x.xms     vòng lặp lâu nhất trong 0,2 s qua. PHẢI < 4.0 ms. Nếu >= 4.0:
              đặt DEBUG_USB 0 trong Config.h rồi so lại (xem mục 6)
  CRSF=a/b    số khung tốt / số khung lỗi CRC. b nên luôn bằng 0.
  Chỉ in khi có phần mềm mở cổng COM và bật DTR (Arduino Serial Monitor, Tera Term, PuTTY đều được).


5) KHI CÓ LỖI
-------------
  FC "RX=MAT" mãi:
     - RX in "[RX] LINK" chưa? Chưa -> TX và RX khác RC_WIFI_CHANNEL / RC_LINK_KEY, hoặc chưa bật TX.
     - RX đã LINK mà FC vẫn MAT -> kiểm tra dây GPIO17 -> PA1 (không nhầm chéo), GND chung, CRSF_BAUD 420000 ở cả hai.
  CRSF=…/N, N tăng liên tục: nhiễu dây UART -> dây ngắn lại, GND chung chắc.
  Serial Monitor FC trắng tron:
     - Tools > USB support phải là "CDC (generic 'Serial' supersede U(S)ART)".
     - Windows có hiện cổng COM mới không? Không hiện -> board có thạch anh 8 MHz không?
       (STM32duino mặc định HSE 8 MHz; thạch anh khác thì USB không chạy được.)
     - Dùng cáp USB có dây dữ liệu (không phải cáp chỉ sạc).
  Hiệu chuẩn báo LỖI: kiểm tra 3.3V/GND joystick, chân ADC1, xoay đủ hành trình ở bước 2.
  Ga từ chối ARM: "ha ga xuong het truoc" -> ga phải ở thấp nhất (hoặc cần ga lò xo phải thả về giữa).


6) AN TOÀN KHI BAY THẬT
-----------------------
  - DEBUG_USB mặc định 1: dòng in được chia nhỏ để không chặn vòng bay (đã mô phỏng trên máy tính),
    nhưng CHƯA đo trên board thật. Lần bay đầu hãy xem L= trên dòng trạng thái: phải < 4.0 ms.
    Muốn chắc ăn tuyệt đối khi bay: DEBUG_USB 0.
  - Khi bay không cắm USB. Trên RX đặt RX_DEBUG 0 nếu không cần in.
  - TX tự khởi động lại giữa chuyến bay (sụt nguồn) = nút ARM về thả = FC DISARM. Dùng pin TX tốt.
  - Mất sóng: RX ngừng gửi khung, FC cắt motor sau CRSF_TIMEOUT_MS (500 ms), y như máy thu ELRS.
  - Mặc định RC_USE_LR_MODE 0 (WiFi thường, tầm vài trăm mét với ăng-ten ngoài). Bật 1 ở CẢ HAI phía
    nếu cần xa hơn, nhưng hãy thử tầm bay ở độ cao thấp trước.


7) CẦN GA CÓ LÒ XO?  (THROTTLE_SPRING trong TX_ESP32.ino)
--------------------------------------------------------
  0 (mặc định): ga trực tiếp: vị trí cần = giá trị ga. Dùng cho cần ga KHÔNG tự về giữa.
  1           : joystick rẻ tiền tự về giữa: đẩy lên ga tăng dần (500 µs/giây), thả ra thì giữ nguyên;
                ở chế độ ALT thì cần hoạt động như cần leo/hạ (giữa = giữ độ cao).
  ĐẶT SAI: nếu bạn có cần ga lò xo mà để mặc định 0 thì thả cần ga sẽ ra ~1500 (không ARM được, an toàn).
           Ngược lại (cần không lò xo mà đặt 1) là nguy hiểm: để cần ở trên giữa thì ga tăng mãi.
