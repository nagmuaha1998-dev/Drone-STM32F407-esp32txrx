/* =====================================================================
 *  TAB DEBUG — XEM SERIAL MONITOR QUA CONG USB COM CUA BOARD F407
 *
 *  Moi 200ms (DEBUG_USB_MS) in MOT dong trang thai:
 *    t=12.3 RX=OK CH[1500 1500 1000 1500 1000 1000 1000 1000] ARM=0 ALT=0
 *    R=0.4 P=-0.2 Y=3.1 H=0.0m Vz=0 M[1000 1000 1000 1000] L=3.1ms CRSF=1234/0
 *
 *  Y NGHIA:
 *    RX=OK/MAT  : FC co/mat khung CRSF tu may thu (failsafe)
 *    CH[...]    : 8 kenh dau, don vi us. CH1 roll, CH2 pitch, CH3 ga, CH4 yaw,
 *                 CH5 ARM, CH7 che do. Kiem tra chieu can o day.
 *    ARM / ALT  : trang thai ARM va giu do cao ben trong FC
 *    R P Y      : goc nghieng (do) tu bo loc Kalman, yaw tu con quay
 *    H, Vz      : do cao (m) va toc do len xuong (cm/s) tu baro/EKF
 *    M[...]     : lenh gui 4 ESC (1000 = tat)
 *    L          : vong lap LAU NHAT trong 200ms qua. PHAI DUOI 4.0ms,
 *                 neu >= 4.0 la vong bay bi tre (tat DEBUG_USB va thu lai)
 *    CRSF=a/b   : so khung tot / so khung loi CRC tu may thu
 *
 *  KHONG CHAN VONG BAY:
 *    - Dong in duoc dung san bang phep tinh so nguyen (khong snprintf/float printf).
 *    - Dong chi duoc day ra USB tung manh <=48 byte moi vong lap, va chi khi
 *      con cho trong bo dem. Khong co may tinh mo Serial Monitor thi bo qua han.
 *    - Port USB CDC chi coi la "mo" khi may tinh bao DTR (Arduino Serial
 *      Monitor, Tera Term, PuTTY deu bao).
 *
 *  Mo Serial Monitor roi se thay banner, roi toi cac dong trang thai.
 *  USB CDC khong quan tam toc do baud, chon bao nhieu cung duoc.
 * ===================================================================== */

#if DEBUG_USB || DEBUG_ARM || DEBUG_EKF

void debugInit(void) {
  DBG_PORT.begin(115200);
}

/* Bao loi nghiem trong (vd cam bien khong tra loi) moi 1 giay, DUNG TRONG
 * vong lap ket o setup(): ham nay in truc tiep nen CO THE CHAN, chi dung
 * khi drone chua bay. */
void debugAlert(const char *msg) {
  static uint32_t last = 0;
  if (millis() - last < 1000) return;
  last = millis();
  if (DBG_PORT) DBG_PORT.println(msg);
}

#else

void debugInit(void) {}
void debugAlert(const char *msg) { (void)msg; }

#endif


#if DEBUG_USB

#define DBG_BUF_SIZE   640
#define DBG_CHUNK      48

static char     dbgBuf[DBG_BUF_SIZE];
static uint16_t dbgLen = 0, dbgPos = 0;
static uint32_t dbgNextMs = 0;
static bool     dbgWasOpen = false;
static bool     dbgBlind = false;        // availableForWrite() khong dung duoc -> gui manh 16 byte co dinh
static uint32_t dbgLoopMaxUs = 0;

void debugLoopUs(uint32_t us) {
  if (us > dbgLoopMaxUs) dbgLoopMaxUs = us;
}

// ---- dung chuoi bang so nguyen, khong snprintf ----
static void dbgC(char c) { if (dbgLen < DBG_BUF_SIZE - 1) dbgBuf[dbgLen++] = c; }
static void dbgS(const char *s) { while (*s) dbgC(*s++); }
static void dbgU(uint32_t v) {
  char t[11]; uint8_t n = 0;
  do { t[n++] = (char)('0' + (v % 10)); v /= 10; } while (v && n < sizeof(t));
  while (n) dbgC(t[--n]);
}
static void dbgI(int32_t v) {
  if (v < 0) { dbgC('-'); dbgU((uint32_t)(-(int64_t)v)); }
  else dbgU((uint32_t)v);
}
// in float voi 1 chu so thap phan, vd -12.3
static void dbgF1(float v) {
  int32_t t = (int32_t)(v * 10.0f + (v >= 0 ? 0.5f : -0.5f));
  if (t < 0) { dbgC('-'); t = -t; }
  dbgU((uint32_t)(t / 10)); dbgC('.'); dbgC((char)('0' + (t % 10)));
}

static void dbgBuildBanner(void) {
  dbgLen = 0; dbgPos = 0;
  dbgS("\r\n==== FC_F405 - Serial Monitor (USB COM) ====\r\n");
  dbgS("May thu: ");
  dbgS(RX_PROTOCOL == 1 ? "CRSF " : "PPM ");
#if RX_PROTOCOL == 1
  dbgU(CRSF_BAUD); dbgS(" baud");
#endif
  dbgS(" | ARM = CH"); dbgU(ARM_CHANNEL + 1); dbgS(" > "); dbgU(ARM_THRESHOLD);
  dbgS(" | GIU DO CAO = CH"); dbgU(MODE_CHANNEL + 1); dbgS(" > "); dbgU(MODE_THR_ALT);
  dbgS("\r\nCot: t | RX | CH1..CH8 (roll pitch ga yaw ARM - che do -) | ARM ALT | R P Y (do) | H (m) Vz (cm/s)"
       " | M1..M4 | L = vong lap max (ms, phai < 4.0) | CRSF tot/loi\r\n\r\n");
}

static void dbgBuildLine(void) {
  dbgLen = 0; dbgPos = 0;
  uint32_t ms = millis();
  dbgS("t="); dbgU(ms / 1000); dbgC('.'); dbgU((ms % 1000) / 100);
  dbgS(receiver_alive() ? " RX=OK" : " RX=MAT");

  dbgS(" CH[");
  for (uint8_t i = 0; i < 8; i++) { if (i) dbgC(' '); dbgI((int32_t)ReceiverValue[i]); }
  dbgC(']');

  dbgS(Armed ? " ARM=1" : " ARM=0");
  dbgS(AltHoldOn ? " ALT=1" : " ALT=0");

  dbgS(" R="); dbgF1(KalmanAngleRoll);
  dbgS(" P="); dbgF1(KalmanAnglePitch);
  dbgS(" Y="); dbgF1(YawAngleDeg);
  dbgS(" H="); dbgF1(AltitudeKalman * 0.01f);
  dbgS("m Vz="); dbgI((int32_t)VelocityKalman);

  // Khi chua ARM, loop() ep motor = THROTTLE_CUT (1000); in dung nhu vay
  // de dong dau tien (luc con o setup, MotorInput chua duoc gan) khong hien 0.
  float m[4] = { MotorInput1, MotorInput2, MotorInput3, MotorInput4 };
  dbgS(" M[");
  for (uint8_t i = 0; i < 4; i++) { if (i) dbgC(' '); dbgI(Armed ? (int32_t)m[i] : (int32_t)THROTTLE_CUT); }
  dbgC(']');

  dbgS(" L="); dbgF1((float)dbgLoopMaxUs * 0.001f); dbgS("ms");
  dbgLoopMaxUs = 0;

#if RX_PROTOCOL == 1
  dbgS(" CRSF="); dbgU(CrsfGoodFrames); dbgC('/'); dbgU(CrsfCrcErrors);
#endif
  dbgS("\r\n");
}

/* Goi MOI VONG LAP (trong loop, trong failsafe, va trong vong cho cua setup). */
void debugUpdate(void) {
  // 1) dang co dong do dang gui -> day tiep mot manh nho
  if (dbgPos < dbgLen) {
    if (!DBG_PORT) { dbgPos = dbgLen = 0; dbgWasOpen = false; return; }   // rut cap / dong monitor giua chung
    uint16_t n = dbgLen - dbgPos;
    if (n > DBG_CHUNK) n = DBG_CHUNK;
    if (dbgBlind) {
      if (n > 16) n = 16;
    } else {
      int room = DBG_PORT.availableForWrite();
      if (room <= 0) return;                    // bo dem day, thu lai vong sau
      if (n > (uint16_t)room) n = (uint16_t)room;
    }
    size_t w = DBG_PORT.write((const uint8_t *)&dbgBuf[dbgPos], n);
    dbgPos = (uint16_t)(dbgPos + w);
    return;
  }

  // 2) ranh: neu chua co ai mo Serial Monitor thi thoi
  if (!DBG_PORT) { dbgWasOpen = false; return; }

  // 3) vua mo Serial Monitor -> gui banner
  if (!dbgWasOpen) {
    dbgWasOpen = true;
    dbgBlind = (DBG_PORT.availableForWrite() <= 0);   // bo dem dang trong ma van bao 0 = ham khong duoc ho tro
    dbgBuildBanner();
    dbgNextMs = millis() + DEBUG_USB_MS;
    return;
  }

  // 4) toi han in dong trang thai
  uint32_t now = millis();
  if ((int32_t)(now - dbgNextMs) < 0) return;
  dbgNextMs = now + DEBUG_USB_MS;
  dbgBuildLine();
}

#else   // DEBUG_USB == 0: cac ham rong, khong ton thoi gian

void debugLoopUs(uint32_t us) { (void)us; }
void debugUpdate(void) {}

#endif
